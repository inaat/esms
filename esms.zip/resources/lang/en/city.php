<?php
return [
    "cities" => 'Cities',
];