<?php
return [
    "districts" => 'Districts',

];