<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
   // protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    // custom logout function
    // redirect to login page
    // public function logout(Request $request)
    // {
    //     $this->guard()->logout();

    //     $request->session()->invalidate();

    //     $request->session()->regenerateToken();

    //     if ($response = $this->loggedOut($request)) {
    //         return $response;
    //     }

    //     return $request->wantsJson()
    //         ? new Response('', 204)
    //         : redirect('/login');
    // }
    public function logout()
    {
        //$this->businessUtil->activityLog(auth()->user(), 'logout');

        request()->session()->flush();
        \Auth::logout();
        return redirect('/login');
    }


    
    protected function redirectTo()
    {
         $user = \Auth::user();
        // if (!$user->can('dashboard.data') && $user->can('sell.create')) {
        //     return '/pos/create';
        // }
       if ($user->user_type == 'teacher') {
       
            return '/dashboard';
         }elseif($user->user_type == 'student'){
            return '/student/dashboard';
         }
         elseif($user->user_type == 'guardian'){
            return '/guardian/dashboard';
         }
         elseif($user->user_type == 'staff'){
            return '/staff/dashboard';
         }
         else{
    return '/home';
}
    }
}
